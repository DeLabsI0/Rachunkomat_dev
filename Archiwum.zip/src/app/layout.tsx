import "./globals.css";
import AuthRouter from '@/components/AuthRouter';

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <AuthRouter>{children}</AuthRouter>
      </body>
    </html>
  );
}
